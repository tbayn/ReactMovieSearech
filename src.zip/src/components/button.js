const Button = ({text, cName}) => {
    return (
        <>
        <button className ={cName}>{text}</button>
        </>
    )
}

export default Button