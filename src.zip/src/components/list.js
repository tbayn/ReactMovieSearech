
function Lists (){

    return (
        <div className={"nav"}>
            <div className={"search"}>
                <button className={"dropBtn"}>Location </button>
                <div className={"drop-content"}>
                    <li>201</li>
                    <li>202</li>
                    <li>203</li> 
                </div>
            </div>

            <div className={"search"}>
                <button className={"dropBtn"}>Deals</button>
                <div className={"drop-content"}>
                    <li>201</li>
                    <li>202</li>
                    <li>203</li> 
                </div>
            </div>

            <div className={"search"}>
                <button className={"dropBtn"}>Foreign</button>
                <div className={"drop-content"}>
                    <li>201</li>
                    <li>202</li>
                    <li>203</li> 
                </div>
            </div>
        </div>
    )}

    export default Lists